item_a = 'cheese'
item_b = 'apple'

# prices per unit
price_a = 4.2
price_b = 1.2
# quantities
quantity_a = 2
quantity_b = 5

cost_a = price_a * quantity_a
cost_b = price_b * quantity_b
print(f"All {item_a} together cost {cost_a} duplonen and all {item_b} together cost {cost_b} duplonen")
print(f"Together they cost {cost_a + cost_b}")
