var = 1
if var<0:
    print("variable is a negative number")
elif var>0:
    print("variable is a positive number")
else:
    print("variable is zero")
